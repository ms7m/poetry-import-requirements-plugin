class BasePlugin:
    """
    Base class for all plugin types
    """

    PLUGIN_API_VERSION = "1.0.0"
